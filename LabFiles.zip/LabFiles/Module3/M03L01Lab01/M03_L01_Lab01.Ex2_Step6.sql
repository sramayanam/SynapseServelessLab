DBCC PDW_SHOWSPACEUSED ('Trip_MedallionID_Skewed');

SELECT *
FROM vSkew
WHERE Table_Name = 'Trip_MedallionID_Skewed'
