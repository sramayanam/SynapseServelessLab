IF object_id('Date') IS NOT NULL           DROP TABLE [Date];
IF object_id('Geography') IS NOT NULL      DROP TABLE [Geography];
IF object_id('HackneyLicense') IS NOT NULL DROP TABLE [HackneyLicense];
IF object_id('Medallion') IS NOT NULL      DROP TABLE [Medallion];
IF object_id('Time') IS NOT NULL           DROP TABLE [Time];
IF object_id('Trip') IS NOT NULL           DROP TABLE [Trip];
IF object_id('Weather') IS NOT NULL        DROP TABLE [Weather];

