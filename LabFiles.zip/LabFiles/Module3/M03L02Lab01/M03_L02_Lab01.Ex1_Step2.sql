INSERT [Trip_MedallionID]
SELECT *
FROM [Trip_MedallionID]
GO 8

