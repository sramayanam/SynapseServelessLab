

--1. Create a simple table to hold data.
CREATE TABLE SalesRLS
    (
    OrderID int,
    SalesRep sysname,
    Product varchar(10),
    Qty int
    );

--2. Populate the table with 6 rows of data, showing 3 orders for each sales representative.
INSERT SalesRLS VALUES 
(1, 'Sales1', 'Valve', 5), 
(2, 'Sales1', 'Wheel', 2), 
(3, 'Sales1', 'Valve', 4),
(4, 'Sales2', 'Bracket', 2), 
(5, 'Sales2', 'Wheel', 5), 
(6, 'Sales2', 'Seat', 5);
-- View the 6 rows in the table
SELECT * FROM SalesRLS;

--3. Create three user accounts that will demonstrate different access capabilities.
CREATE USER Manager WITHOUT LOGIN;
CREATE USER Sales1 WITHOUT LOGIN;
CREATE USER Sales2 WITHOUT LOGIN;
CREATE USER Sales3 WITHOUT LOGIN;

--4. Grant read access on the table to each of the users.
GRANT SELECT ON SalesRLS TO Manager;
GRANT SELECT ON SalesRLS TO Sales1;
GRANT SELECT ON SalesRLS TO Sales2;
GRANT SELECT ON SalesRLS TO Sales3;

--5. Create a new schema, and an inline table valued function. 
--   The function returns 1 when a row in the SalesRep column is the same as the user executing the query (@SalesRep = USER_NAME()) 
--   or if the user executing the query is the Manager user (USER_NAME() = 'Manager').

CREATE SCHEMA Security;
GO

CREATE FUNCTION Security.fn_securitypredicate(@SalesRep AS sysname)
    RETURNS TABLE
WITH SCHEMABINDING
AS
    RETURN SELECT 1 AS fn_securitypredicate_result 
WHERE @SalesRep = USER_NAME() OR USER_NAME() = 'Manager';

--6. Create a security policy adding the function as a filter predicate. The state must be set to ON to enable the policy.
CREATE SECURITY POLICY SalesFilter
ADD FILTER PREDICATE Security.fn_securitypredicate(SalesRep) 
ON dbo.SalesRLS
WITH (STATE = ON);

--7. Now test the filtering predicate, by selected from the Sales table as each user.
EXECUTE AS USER = 'Sales1';
SELECT * FROM SalesRLS; 
REVERT;

EXECUTE AS USER = 'Sales2';
SELECT * FROM SalesRLS; 
REVERT;

EXECUTE AS USER = 'Sales3';
SELECT * FROM SalesRLS; 
REVERT;

EXECUTE AS USER = 'Manager';
SELECT * FROM SalesRLS; 
REVERT;

GRANT UPDATE ON SalesRLS TO Sales1;
EXECUTE AS USER = 'Sales1';
UPDATE SalesRLS
Set Qty=100
where OrderID=4; 
REVERT;

--8. Alter the security policy to disable the policy.
ALTER SECURITY POLICY SalesFilter
WITH (STATE = OFF);

--Now the Sales1 and Sales2 users can see all 6 rows.
EXECUTE AS USER = 'Sales1';
SELECT * FROM SalesRLS; 
REVERT;

EXECUTE AS USER = 'Sales2';
SELECT * FROM SalesRLS; 
REVERT;

--Cleanup
DROP SECURITY POLICY SalesFilter
DROP FUNCTION Security.fn_securitypredicate
DROP SCHEMA Security
DROP TABLE SalesRLS
DROP USER Manager
DROP USER Sales1 
DROP USER Sales2
DROP USER Sales3