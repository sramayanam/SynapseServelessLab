﻿-- 0. Creating TABLE
CREATE TABLE SalesDataClassification
    (
    OrderID int,
    SalesRep sysname,
    Product varchar(10),
    Qty int
    );

--1. View the classification information for each
--   classified table and column in the database.
SELECT
    SCHEMA_NAME(sys.all_objects.schema_id) as SchemaName,
    sys.all_objects.name AS [TableName], sys.all_columns.name As [ColumnName],
    [Label], [Label_ID], [Information_Type], [Information_Type_ID]
FROM
          sys.sensitivity_classifications
left join sys.all_objects on sys.sensitivity_classifications.major_id = sys.all_objects.object_id
left join sys.all_columns on sys.sensitivity_classifications.major_id = sys.all_columns.object_id
                         and sys.sensitivity_classifications.minor_id = sys.all_columns.column_id


						
--2. Add a new classification for the SalesDataClassification table, Product column
ADD SENSITIVITY CLASSIFICATION TO
    SalesDataClassification.Product
    WITH ( LABEL='Other', INFORMATION_TYPE='General' )


--3. View the classification information for each
--   classified table and column in the SalesDataClassification table
SELECT
    SCHEMA_NAME(sys.all_objects.schema_id) as SchemaName,
    sys.all_objects.name AS [TableName], sys.all_columns.name As [ColumnName],
    [Label], [Label_ID], [Information_Type], [Information_Type_ID]
FROM
          sys.sensitivity_classifications
left join sys.all_objects on sys.sensitivity_classifications.major_id = sys.all_objects.object_id
left join sys.all_columns on sys.sensitivity_classifications.major_id = sys.all_columns.object_id
                         and sys.sensitivity_classifications.minor_id = sys.all_columns.column_id
WHERE sys.all_objects.name = 'Product'


--4. Drop classifications for the SalesDataClassification table
DROP SENSITIVITY CLASSIFICATION FROM
    SalesDataClassification.Product


--5. Ensure all entires for the SalesDataClassification table have been dropped
--  This query should return 0 records
SELECT
    SCHEMA_NAME(sys.all_objects.schema_id) as SchemaName,
    sys.all_objects.name AS [TableName], sys.all_columns.name As [ColumnName],
    [Label], [Label_ID], [Information_Type], [Information_Type_ID]
FROM
          sys.sensitivity_classifications
left join sys.all_objects on sys.sensitivity_classifications.major_id = sys.all_objects.object_id
left join sys.all_columns on sys.sensitivity_classifications.major_id = sys.all_columns.object_id
                         and sys.sensitivity_classifications.minor_id = sys.all_columns.column_id
WHERE sys.all_objects.name = 'Product'


-- END OF LAB --