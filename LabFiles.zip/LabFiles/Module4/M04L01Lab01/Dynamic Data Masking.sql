--Pre-reqs: Creating table if not exists
IF object_id('Geography') IS NOT NULL      DROP TABLE [Geography];
CREATE TABLE [dbo].[Geography]
(
    [GeographyID] int NOT NULL,
    [ZipCodeBKey] varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
    [County] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [City] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [State] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [Country] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
    [ZipCode] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
WITH
(   DISTRIBUTION = ROUND_ROBIN,
    CLUSTERED COLUMNSTORE INDEX
);
COPY INTO [dbo].[Geography]
FROM 'https://nytaxiblob.blob.core.windows.net/2013/Geography'
WITH(FILE_TYPE = 'CSV',
	 FIELDTERMINATOR = ',',
	 FIELDQUOTE = ''
	 )OPTION (LABEL = 'COPY : Load [dbo].[Geography] - Taxi dataset');

--1. Add Dynamic Data Masking to TaxiZones table
ALTER TABLE [dbo].[Geography] 
ALTER COLUMN [ZipCode] varchar(50) MASKED WITH (FUNCTION = 'partial(2,"XXX",0)');  

--2. Create a test user
CREATE USER TestUser WITHOUT LOGIN; 
GO 
GRANT SELECT ON [dbo].[Geography] TO TestUser; 
GO  

--3. Query the table as Test user - Queries executed the as the TestUser view masked data. 
EXECUTE AS USER = 'TestUser';   
SELECT * FROM [dbo].[Geography] ;   
REVERT;    
GO 

--4. Remove masking on Zone column
ALTER TABLE [dbo].[Geography] ALTER COLUMN [ZipCode] DROP MASKED

--5. Cleanup
DROP USER TestUser 